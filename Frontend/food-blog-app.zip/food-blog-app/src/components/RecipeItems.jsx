import React from 'react'
import { useLoaderData } from 'react-router-dom'
import foodRecipe1 from '../assets/foodRecipe1.png'
import { IoIosStopwatch } from 'react-icons/io'
import { IoIosHeart } from 'react-icons/io'

export default function RecipeItems() {
  const allRecipes = useLoaderData()
  console.log(allRecipes)

  return (
    <>
      <div className='card-container'>
        {allRecipes?.map((item, index) => {
          return (
            <div key={index} className='card'>
              <img
                src={`http://localhost:5000/images/${item.CoverImage}`}
                width='120px'
                height='100px'
              ></img>
              <div className='card-body'>
                <div className='Title'>{item.Title} </div>
                <div className='Icons'>
                  <div className='Timer'>
                    <IoIosStopwatch />
                    30 min
                  </div>
                  <IoIosHeart />
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </>
  )
}
