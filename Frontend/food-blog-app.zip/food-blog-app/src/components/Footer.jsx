import React from 'react'

export default function Footer() {
  return (
    <>
      <div className='footer'>
        <p>@cpoyright of FoodCompany</p>
      </div>
    </>
  )
}
